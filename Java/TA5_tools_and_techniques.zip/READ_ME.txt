TO RUN THE CODE:
1. Just open the test.sh file and it will compile and run the code for you.
2. if doesn't work and you're in linux you can type in the cmd, "sh test.sh

If your are going to run this in netbeans make sure to add:
package AccountManagement;
in the beginning of each java file.

