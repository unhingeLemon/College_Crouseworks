clear
javac View.java
javac AccountManagement.java
java AccountManagement
